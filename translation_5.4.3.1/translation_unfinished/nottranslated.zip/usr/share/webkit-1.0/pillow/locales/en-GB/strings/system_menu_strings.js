Settings	
Shop in Kindle Store	
