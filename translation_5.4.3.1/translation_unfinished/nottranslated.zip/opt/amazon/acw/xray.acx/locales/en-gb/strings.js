(cont.)	
All	
Artists	
Book	
Chapter	
Creatures	
Current Chapter	
Current Page	
Dates	
Entire Book	
Equations	
Events	
Full Wikipedia Article	
Highlights	
Holidays	
Hotels	
Ingredients	
Location ${location}	
Locations ${start} - ${end}	
Monsters	
More on Shelfari	
More	
Organisations	
Page ${page}	
Page ${start} - ${end}	
Page	
People	
Places	
Potions	
Quotes	
Recipes	
Restaurants	
See more about this book.	
Showing ${range} of ${total}	
Spells	
Subject to a <span class="license">Creative Commons Licence</span>	
Terms	
Theorems	
This book does not contain X-Ray concepts.	
This chapter does not contain X-Ray concepts.	
This page does not contain X-Ray concepts.	
Works	
X-Ray concepts are not yet available for this book. See additional book information.	
X-Ray is not available for this book	
X-Ray	
en-gb	
http://creativecommons.org/licenses/by-sa/3.0/	
loc.${location}	
loc.${start} - ${end}	
p.${page}	
p.${start} - ${end}	
