Amazon	
Another page with the same URL is already bookmarked.<br><br>Do you wish to overwrite it?	
Article Mode	
BBC News	
Bookmark this Page	
Bookmarks	
Browser Settings	
Clear Cookies	
Clear History	
Disable Images	
Disable JavaScript	
Download Failed	
Download File	
Download {filename}?<br><br>Once the download is complete, the file will appear on the Home screen. &nbsp;Are you sure you wish to proceed?	
Due to local restrictions, web browsing is not available for all countries.	
Duplicate Bookmark	
Edit Bookmark	
Enable Images	
Enable JavaScript	
Facebook	
Gmail	
Google	
History	
In order to browse, you must first register your Kindle with your Amazon user account.	
Internet Movie DB	
Invalid Certificate	
Invalid File Type	
Invalid Protocol	
Registration Required	
Remove a Bookmark	
Search	
Settings	
Sorry, access to Whispernet is blocked.	
Sorry, application is invalid.	
Sorry, roaming is not allowed.	
Sorry, the application has exceeded its quota.	
Sorry, the application was blocked.	
Sorry, the browser cannot access this website currently. &nbsp;Please try again later.	
Sorry, the browser cannot access this website.	
Sorry, the device was blocked.	
The Daily Mail	
There is a problem with your Kindle account.<p>Please contact Customer Service at www.kindle.com/support.</p>	
Today - {date}	
Twitter	
Upload File	
We are experiencing some technical difficulties. Please try again later.	
Web Address	
Web Browser cannot download files using this protocol. &nbsp;Only HTTP and HTTPS protocols are supported.	
Web Browser cannot download this kind of file.<p>Only files with the extension .AZW, .PRC, .MOBI or .TXT can be downloaded to your Kindle.</p>	
Web Browser does not support file uploads.	
Web Browser downloaded {filename} successfully.	
Web Browser is unable to establish a secure connection. Do you still want to proceed?	
Web Browser requires a Wi-Fi connection. &nbsp;Tap OK to establish a Wi-Fi connection.	
Web Browser was unable to download {filename}. &nbsp;Please try again later.	
Web Mode	
Web	
Website Inaccessible	
Wi-Fi Connection Required	
Wikipedia	
Yahoo Mail	
Yahoo	
Yesterday - {date}	
browserStrings	
http://en.wikipedia.org/	
http://m.facebook.com/	
http://m.gmail.com/	
http://m.yahoo.com/mail?.intl=gb	
http://mobile.twitter.com/	
http://news.bbc.co.uk/	
http://uk.imdb.com/	
http://uk.yahoo.com/	
http://www.amazon.co.uk/	
http://www.dailymail.co.uk/	
http://www.google.co.uk/	
http://www.google.co.uk/search?q=	
s go function	
strings', 'object	
